CREATE VIEW containers
as
    select container_id, round(sum(x * y * z),2) as occupied_volume
    from freight f
    left join boxes b on f.box_id = b.id
    group by container_id;

